from datetime import date,timedelta, datetime
import math


def get_days(y1, m1, d1, y2, m2, d2):
    f_date = date(y1, m1, d1)
    l_date = date(y2, m2, d2)
    delta = l_date - f_date
    #print(delta.days)
    return delta.days


def get_dayname(y1, m1, d1):
    week_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    week_num = date(y1, m1, d1).weekday()
    #print(week_days[week_num])
    return week_days[week_num]


def get_no_weeks(y1, m1, d1, y2, m2, d2):
    start_date = date(y1, m1, d1)
    end_date = date(y2, m2, d2)
    monday1 = (start_date - timedelta(days=start_date.weekday()))
    monday2 = (end_date - timedelta(days=end_date.weekday()))
    diff = monday2 - monday1
    no_weeks = (diff.days / 7) + math.ceil(diff.seconds / 86400)
    #print('Weeks:', no_weeks)
    return int(no_weeks)


def get_no_months(y1, m1, d1, y2, m2, d2):
    start_date = date(y1, m1, d1)
    end_date = date(y2, m2, d2)
    num_months = (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month)
    #print(num_months)
    return num_months


def inc_date(y1, m1, d1, no_days):
    dt = date(y1, m1, d1)
    dt += timedelta(days=no_days)
    #print(dt)
    return dt.year,dt.month,dt.day


def get_working_days(y1, m1, d1, y2, m2, d2):
    f_date = date(y1, m1, d1)
    l_date = date(y2, m2, d2)
    delta = l_date - f_date
    print(delta.days)
    working_days = 0
    for i in range(0, delta.days):
        ty, tm, td = inc_date(y1,m1,d1,i)
        week_num = date(ty, tm, td).weekday()
        first_w = date(ty, tm, 1).isoweekday()
        saturday2 = 14 - first_w
        saturday4 = 28 - first_w
        if week_num<5:
            working_days += 1
            #print(i, week_num, working_days)
        elif week_num==5 and td != saturday2 and td!= saturday4:
            working_days += 1
    return working_days

def is_working_day(ty, tm, td):
    week_num = date(ty, tm, td).weekday()
    first_w = date(ty, tm, 1).isoweekday()
    saturday2 = 14 - first_w
    saturday4 = 28 - first_w
    if week_num < 5:
        return True
        # print(i, week_num, working_days)
    elif week_num == 5 and td != saturday2 and td != saturday4:
        return True
    return False

def compare_dates(y1,m1,d1, y2,m2,d2):
    # date in yyyy/mm/dd format
    d1 = datetime(y1, m1, d1)
    d2 = datetime(y2, m2, d2)
    print('d1',d1)
    print('d2',d2)
    # Comparing the dates will return
    # either True or False
    print("d1 is greater than d2 : ", d1 > d2)
    print("d1 is less than d2 : ", d1 < d2)
    print("d1 is not equal to d2 : ", d1 != d2)
    return d1 >= d2

if __name__ == '__main__':
    #day_cnt = get_days(2020,1,1,2020,12,31)
    #print(day_cnt)

    day_cnt = get_working_days (2020, 11, 1, 2020, 1, 31)
    print('Working',day_cnt)

    #d_name = get_dayname(2020,5,20)
    #print(d_name)

    #w_cnt = get_no_weeks(2020,1,1,2021,1,10)
    #print(w_cnt)

    #m_cnt = get_no_months(2021, 1, 1, 2021, 2, 10)
    #print(m_cnt)

    y2, m2, d2 = inc_date(2022,6,25,14)
    print(y2, m2, d2)

    #res_flag = compare_dates(2020, 11, 1, 2020, 1, 31)
    #print('resflag', res_flag)